﻿using System;

class Program
{
    static void Main()
    {
        Random random = new Random();
        int tajnaChislo = random.Next(0, 16); // от 0 до 15 включително
        int otgovor = -1;

        Console.WriteLine("Познай числото от 0 до 15!");

        while (otgovor != tajnaChislo)
        {
            Console.Write("Въведи число: ");
            string vhod = Console.ReadLine();

            if (!int.TryParse(vhod, out otgovor))
            {
                Console.WriteLine("Моля, въведи валидно число.");
                continue;
            }

            if (otgovor < 0 || otgovor > 15)
            {
                Console.WriteLine("Числото трябва да е между 0 и 15.");
                continue;
            }

            if (otgovor < tajnaChislo)
            {
                Console.WriteLine("Тайното число е по-голямо.");
            }
            else if (otgovor > tajnaChislo)
            {
                Console.WriteLine("Тайното число е по-малко.");
            }
        }

        Console.WriteLine("Честито! Позна числото!");
    }
}
