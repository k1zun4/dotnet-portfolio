﻿using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;

class Program
{
    static void Main()
    {
        // Списък с възможни тайни думи, от които ще бъде избрана една на случаен принцип
        string[] dumi = { "ябълка", "книга", "компютър", "програма", "цвете" };

        // Създава генератор на случайни числа
        Random random = new Random();

        // Избира произволна дума от списъка
        string tajnaDuma = dumi[random.Next(dumi.Length)];

        // Създава масив от символи със същата дължина като тайната дума, съдържащи само подчертавки
        char[] pokazaniBukvi = new char[tajnaDuma.Length];
        for (int i = 0; i < pokazaniBukvi.Length; i++)
            pokazaniBukvi[i] = '_'; // Първоначално всички букви са скрити

        // Задава брой позволени грешни опити
        int ostavashtiOpiti = 7;

        // Създава множество, което ще пази вече въведените букви
        HashSet<char> izgovoreniBukvi = new HashSet<char>();

        // Извежда начално съобщение
        Console.WriteLine("Добре дошли във Бесеницата! Познай думата, имаш 7 опита.");
        Console.WriteLine("За да излезеш, въведи 'exit'.");

        // Основен цикъл на играта – докато има останали опити и думата не е напълно разкрита
        while (ostavashtiOpiti > 0 && new string(pokazaniBukvi) != tajnaDuma)
        {
            // Показва текущото състояние на думата и друга информация
            Console.WriteLine("\nДума: " + string.Join(" ", pokazaniBukvi));
            Console.WriteLine("Изговорени букви: " + string.Join(", ", izgovoreniBukvi));
            Console.WriteLine("Остават опити: " + ostavashtiOpiti);
            Console.Write("Въведи буква (или 'exit' за изход): ");

            // Чете входа от потребителя
            string vhod = Console.ReadLine();

            // Проверка за команда за изход
            if (vhod != null && vhod.ToLower() == "exit")
            {
                Console.WriteLine("Излизаш от играта. Довиждане!");
                return; // Излизаме от програмата
            }

            // Проверява дали въведеният низ не е празен и съдържа точно една буква
            if (string.IsNullOrWhiteSpace(vhod) || vhod.Length != 1)
            {
                Console.WriteLine("Моля, въведи една буква.");
                continue; // Продължава към следващото завъртане на цикъла
            }

            // Превръща буквата в малка
            vhod = vhod.ToLower();
            char bukva = vhod[0];

            // Проверява дали въведеният символ е буква от кирилицата чрез регулярни изрази
            if (!Regex.IsMatch(vhod, @"^[а-яА-Я]$"))
            {
                Console.WriteLine("Поддържат се само букви на Кирилицата. Опитът не се отнема.");
                continue; // Ако не е буква от кирилицата – не се отчита опит
            }

            // Проверява дали буквата вече е въвеждана
            if (izgovoreniBukvi.Contains(bukva))
            {
                Console.WriteLine("Вече си въвел тази буква.");
                continue; // Ако да – не я проверява отново
            }

            // Добавя новата буква към използваните
            izgovoreniBukvi.Add(bukva);

            // Ако буквата се съдържа в тайната дума
            if (tajnaDuma.Contains(bukva))
            {
                // Заменя съответните подчертавки с действителната буква
                for (int i = 0; i < tajnaDuma.Length; i++)
                {
                    if (tajnaDuma[i] == bukva)
                        pokazaniBukvi[i] = bukva;
                }
                Console.WriteLine("Добре! Буквата е в думата.");
            }
            else
            {
                // Ако буквата я няма в думата – намалява броя на опитите
                ostavashtiOpiti--;
                Console.WriteLine("Грешка! Тази буква я няма.");
            }
        }

        // Проверка за край на играта – дали потребителят е познал думата или е изгубил
        if (new string(pokazaniBukvi) == tajnaDuma)
            Console.WriteLine($"\nЧестито! Позна думата: {tajnaDuma}");
        else
            Console.WriteLine($"\nИзчерпа опитите! Думата беше: {tajnaDuma}");
    }
}
