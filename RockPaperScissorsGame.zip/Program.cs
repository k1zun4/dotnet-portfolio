﻿using System;

class KamakNozhicaHartia
{
    static void Main()
    {
        Console.WriteLine("Добре дошъл в играта 'Камък, ножица, хартия'!");
        Console.WriteLine("Въведи камък, ножица или хартия, за да играеш. За изход въведи 'изход'.");

        string[] options = { "камък", "ножица", "хартия" };
        Random rand = new Random();

        while (true)
        {
            Console.Write("\nТвой избор: ");
            string igrachIzbor = Console.ReadLine().ToLower();

            // Проверка за изход от играта
            if (igrachIzbor == "изход")
            {
                Console.WriteLine("Благодаря, че игра!");
                break;
            }

            // Проверка дали изборът е валиден
            if (Array.IndexOf(options, igrachIzbor) == -1)
            {
                Console.WriteLine("Моля, въведи камък, ножица или хартия.");
                continue;
            }

            // Избор на компютъра
            string kompIzbor = options[rand.Next(options.Length)];
            Console.WriteLine($"Компютърът избра: {kompIzbor}");

            // Определяне на победителя
            if (igrachIzbor == kompIzbor)
            {
                Console.WriteLine("Равенство!");
            }
            else if ((igrachIzbor == "камък" && kompIzbor == "ножица") ||
                     (igrachIzbor == "ножица" && kompIzbor == "хартия") ||
                     (igrachIzbor == "хартия" && kompIzbor == "камък"))
            {
                Console.WriteLine("Ти печелиш!");
            }
            else
            {
                Console.WriteLine("Компютърът печели!");
            }
        }
    }
}
