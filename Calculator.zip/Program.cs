﻿using System;

class Kalkulator
{
    static void Main()
    {
        Console.WriteLine("Прост конзолен калкулатор");
        Console.WriteLine("Достъпни операции:");
        Console.WriteLine("+ : събиране");
        Console.WriteLine("- : изваждане");
        Console.WriteLine("* : умножение");
        Console.WriteLine("/ : деление");
        Console.WriteLine("% : процент от число");
        Console.WriteLine("Въведи 'exit' за изход от програмата");

        while (true)  // Безкраен цикъл, докато потребителят не напише 'exit'
        {
            Console.Write("\nВъведи първото число: ");
            string vhod1 = Console.ReadLine();

            if (vhod1.ToLower() == "exit")  // Проверка за команда за изход
                break;

            // Проверка дали първият вход е валидно число
            if (!double.TryParse(vhod1, out double chislo1))
            {
                Console.WriteLine("Грешка: Моля, въведи валидно число.");
                continue;  // Връщаме се в началото на цикъла
            }

            Console.Write("Въведи операция (+, -, *, /, %): ");
            string operacia = Console.ReadLine();

            if (operacia.ToLower() == "exit")  // Проверка за команда за изход
                break;

            // Проверка дали операцията е валидна
            if (operacia != "+" && operacia != "-" && operacia != "*" && operacia != "/" && operacia != "%")
            {
                Console.WriteLine("Грешка: Невалидна операция.");
                continue;  // Връщаме се в началото на цикъла
            }

            // Ако операцията е процент, изчисляваме процента от първото число
            if (operacia == "%")
            {
                double rezultat = chislo1 / 100;
                Console.WriteLine($"{chislo1}% = {rezultat}");
                continue;  // Продължаваме с нов цикъл
            }

            // При другите операции ни трябва второ число
            Console.Write("Въведи второто число: ");
            string vhod2 = Console.ReadLine();

            if (vhod2.ToLower() == "exit")  // Проверка за команда за изход
                break;

            // Проверка дали вторият вход е валидно число
            if (!double.TryParse(vhod2, out double chislo2))
            {
                Console.WriteLine("Грешка: Моля, въведи валидно число.");
                continue;  // Връщаме се в началото на цикъла
            }

            double rezultatFinal = 0;
            bool validnaOperacia = true;

            // Извършваме съответната операция
            switch (operacia)
            {
                case "+":
                    rezultatFinal = chislo1 + chislo2;
                    break;
                case "-":
                    rezultatFinal = chislo1 - chislo2;
                    break;
                case "*":
                    rezultatFinal = chislo1 * chislo2;
                    break;
                case "/":
                    if (chislo2 == 0)
                    {
                        Console.WriteLine("Грешка: Деление на нула не е позволено.");
                        validnaOperacia = false;
                    }
                    else
                    {
                        rezultatFinal = chislo1 / chislo2;
                    }
                    break;
            }

            // Ако операцията е валидна, показваме резултата
            if (validnaOperacia)
                Console.WriteLine($"Резултат: {rezultatFinal}");
        }

        Console.WriteLine("Изход от калкулатора. Довиждане!");
    }
}
